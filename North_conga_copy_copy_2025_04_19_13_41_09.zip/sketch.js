function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);

<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>P5.js 3D Example</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/p5.js/1.4.0/p5.js"></script>
</head>
<body>
  <script>
    function setup() {
      createCanvas(windowWidth, windowHeight, WEBGL);
    }

    function draw() {
      background(200);
      rotateX(frameCount * 0.01);
      rotateY(frameCount * 0.01);
      box(100);
    }
  </script>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>City at the Bus Stop</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/p5.js/1.4.0/p5.js"></script>
</head>
<body>
    <script>
        function setup() {
            createCanvas(windowWidth, windowHeight);
            noLoop();  // We don't need to redraw every frame, since the city is static
        }

        function draw() {
            background(200, 220, 255);  // Sky blue color for the background

            // Draw the bus stop
            drawBusStop();

            // Draw buildings
            drawBuildings();

            // Draw furniture stores
            drawFurnitureStores();
        }

        // Function to draw a bus stop
        function drawBusStop() {
            fill(150, 75, 0); // Brown color for the bus stop
            rect(100, height - 150, 200, 50);  // Simple rectangle for the bus stop
            fill(255); // White color for the roof
            triangle(100, height - 150, 200, height - 150, 150, height - 200);  // Roof of the bus stop
        }

        // Function to draw buildings
        function drawBuildings() {
            for (let i = 0; i < 10; i++) {
                let x = random(width);  // Random x-coordinate for variety
                let buildingHeight = random(100, 400);  // Tall or small buildings
                let buildingWidth = random(50, 150);  // Varying widths for the buildings

                fill(random(150, 255), random(150, 255), random(150, 255));  // Random color for each building
                rect(x, height - buildingHeight, buildingWidth, buildingHeight);  // Draw the building
            }
        }

        // Function to draw furniture stores
        function drawFurnitureStores() {
            for (let i = 0; i < 5; i++) {
                let x = random(width);
                let storeHeight = random(60, 100);
                let storeWidth = random(100, 200);

                fill(200, 150, 100);  // Brownish color for furniture stores
                rect(x, height - storeHeight, storeWidth, storeHeight);  // Draw the store

                fill(255);  // White text for the store sign
                textSize(20);
                text('Furniture', x + 10, height - storeHeight + 30);  // Label the store
            }
        }
    </script>
</body>
</html><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interactive City Game</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/p5.js/1.4.0/p5.js"></script>
</head>
<body>
    <script>
        let menuOpen = false;
        let joystickX = 0, joystickY = 0, joystickRadius = 50;
        let jumpBarHeight = 40;
        let lastClickTime = 0;

        function setup() {
            createCanvas(windowWidth, windowHeight);
            noLoop();
        }

        function draw() {
            background(200, 220, 255);  // Sky blue background

            // Draw the city (same as before)
            drawCity();

            // Draw the button to open the menu
            drawMenuButton();

            if (menuOpen) {
                drawMenu();
            }

            // Draw joystick
            drawJoystick();

            // Draw jump bar
            drawJumpBar();
        }

        // Draw the city with buildings
        function drawCity() {
            fill(150, 75, 0);  // Brown color for buildings
            rect(100, height - 150, 200, 50);
        }

        // Draw the button to open/close the menu
        function drawMenuButton() {
            fill(100, 150, 255);  // Light blue button color
            ellipse(50, 50, 80, 50);  // Oval button

            fill(255);  // White text for the button label
            textSize(20);
            textAlign(CENTER, CENTER);
            text("Menu", 50, 50);
        }

        // Draw the menu when open
        function drawMenu() {
            fill(0, 0, 0, 150);  // Semi-transparent black background for the menu
            rect(0, 0, width, height);  // Full screen dark background

            fill(255);
            textSize(30);
            textAlign(CENTER, TOP);
            text("Settings", width / 2, height / 4 - 100);

            textSize(20);
            text("How to Play: Double-click anywhere to open doors.", width / 2, height / 4);
            text("How to Run: Use the joystick.", width / 2, height / 4 + 30);
            text("How to Jump: Press the jump bar below.", width / 2, height / 4 + 60);

            // Close menu button
            fill(255, 0, 0);
            rect(width / 2 - 50, height / 2 + 100, 100, 50);  // Close button
            fill(255);
            textSize(20);
            text("Close", width / 2, height / 2 + 125);
        }

        // Draw the joystick
        function drawJoystick() {
            fill(200, 200, 255);
            ellipse(joystickX, joystickY, joystickRadius * 2, joystickRadius * 2);  // Outer circle of the joystick

            fill(100, 150, 255);
            ellipse(joystickX, joystickY, joystickRadius, joystickRadius);  // Inner circle

            // Joystick control interaction (simulate movement)
            if (mouseIsPressed && dist(mouseX, mouseY, joystickX, joystickY) < joystickRadius) {
                joystickX = mouseX;
                joystickY = mouseY;
            }
        }

        // Draw the jump bar
        function drawJumpBar() {
            fill(100, 200, 100);
            rect(0, height - jumpBarHeight, width, jumpBarHeight);  // Jump bar at the bottom
        }

        // Detect double-clicks to open doors
        function mousePressed() {
            let currentTime = millis();
            if (currentTime - lastClickTime < 500) {  // Double-click detection (500 ms interval)
                alert("Door Opened!");
            }
            lastClickTime = currentTime;
        }

        // Toggle the menu open/close
        function mouseClicked() {
            // Check if the menu button is clicked
            let buttonDist = dist(mouseX, mouseY, 50, 50);
            if (buttonDist < 40) {
                menuOpen = !menuOpen;
            }

            // Close menu when the close button is clicked
            if (menuOpen && mouseX > width / 2 - 50 && mouseX < width / 2 + 50 && mouseY > height / 2 + 100 && mouseY < height / 2 + 150) {
                menuOpen = false;
            }
        }
    </script>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/p5.js/1.4.0/p5.js"></script>
</head>
<body>
  <script>
    let gameState = "intro";
    let yesButton;

    function setup() {
      createCanvas(windowWidth, windowHeight);
      yesButton = createButton("YES");
      yesButton.position(100, height - 100);
      yesButton.mousePressed(handleYes);
      yesButton.hide(); // Only show during intro
    }

    function draw() {
      background(200, 220, 255);

      if (gameState === "intro") {
        drawBusStopScene();
        drawUnknown();
        fill(0);
        textSize(20);
        text("Unknown: You want some money?", 100, height - 150);
        yesButton.show();
      }

      if (gameState === "gearUp") {
        drawBenchScene();
        drawTabletIcon();
        drawPhoneIcon();
      }
    }

    function drawBusStopScene() {
      fill(150, 75, 0);
      rect(100, height - 150, 200, 50);
    }

    function drawUnknown() {
      fill(0);
      rect(320, height - 180, 50, 100); // Unknown character
      fill(255);
      text("Unknown", 320, height - 190);
    }

    function handleYes() {
      gameState = "gearUp";
      yesButton.hide();
    }

    function drawBenchScene() {
      fill(150, 75, 0);
      rect(100, height - 150, 200, 50); // Bench
      fill(0);
      textSize(16);
      text("Unknown: Here's a phone and a tablet.", 100, height - 160);
      text("You will be selling flowers to customers.", 100, height - 140);
    }

    function drawTabletIcon() {
      fill(80);
      rect(width - 60, 20, 40, 30); // Tablet icon
      fill(255);
      textSize(10);
      text("Tablet", width - 60, 15);
    }

    function drawPhoneIcon() {
      fill(50);
      rect(width - 60, 60, 30, 50); // Phone icon
      fill(255);
      textSize(10);
      text("Phone", width - 60, 55);
    }
  </script>
</body>
</html>
let gameState = "intro";
let yesButton;
let flowerSales = 0;
let missionButton1, missionButton2;

function setup() {
  createCanvas(windowWidth, windowHeight);

  // YES Button
  yesButton = createButton("YES");
  yesButton.position(100, height - 100);
  yesButton.mousePressed(handleYes);
  yesButton.hide();

  // Mission Buttons (hidden at first)
  missionButton1 = createButton("Deliver Rare Flower");
  missionButton2 = createButton("Build New Flower Stand");

  missionButton1.position(width / 2 - 100, height / 2);
  missionButton2.position(width / 2 - 100, height / 2 + 50);

  missionButton1.mousePressed(() => alert("Mission 1 Accepted!"));
  missionButton2.mousePressed(() => alert("Mission 2 Accepted!"));

  missionButton1.hide();
  missionButton2.hide();
}

function draw() {
  background(200, 220, 255);

  if (gameState === "intro") {
    drawBusStopScene();
    drawUnknown();
    fill(0);
    textSize(20);
    text("Unknown: You want some money?", 100, height - 150);
    yesButton.show();
  }

  if (gameState === "gearUp") {
    drawBenchScene();
    drawTabletIcon();
    drawPhoneIcon();

    // Simulate selling flowers
    fill(0);
    text("Flowers Sold: " + flowerSales + "/50", 100, 50);
    fill(0, 200, 0);
    rect(100, 80, 150, 30);
    fill(255);
    text("Sell Flower", 125, 100);

    if (
      mouseIsPressed &&
      mouseX > 100 &&
      mouseX < 250 &&
      mouseY > 80 &&
      mouseY < 110
    ) {
      flowerSales++;
      if (flowerSales >= 50) {
        gameState = "missions";
      }
    }
  }

  if (gameState === "missions") {
    drawMissionMenu();
  }
}

function handleYes() {
  gameState = "gearUp";
  yesButton.hide();
}

function drawBusStopScene() {
  fill(150, 75, 0);
  rect(100, height - 150, 200, 50);
}

function drawUnknown() {
  fill(0);
  rect(320, height - 180, 50, 100);
  fill(255);
  text("Unknown", 320, height - 190);
}

function drawBenchScene() {
  fill(150, 75, 0);
  rect(100, height - 150, 200, 50);
  fill(0);
  textSize(16);
  text("Unknown: Here's a phone and a tablet.", 100, height - 160);
}

function drawTabletIcon() {
  fill(80);
  rect(width - 60, 20, 40, 30);
  fill(255);
  textSize(10);
  text("Tablet", width - 60, 15);
}

function drawPhoneIcon() {
  fill(50);
  rect(width - 60, 60, 30, 50);
  fill(255);
  textSize(10);
  text("Phone", width - 60, 55);
}

function drawMissionMenu() {
  fill(0, 0, 0, 180);
  rect(0, 0, width, height);

  fill(255);
  textSize(24);
  textAlign(CENTER);
  text("Choose Your Mission", width / 2, height / 3);

  missionButton1.show();
  missionButton2.show();
}missionButton1.mousePressed(() => {
  gameState = "mission1";
  missionButton1.hide();
  missionButton2.hide();
});if (gameState === "mission1") {
  drawCityScene();
  drawBouquet();

  // Show mission text
  fill(255);
  textSize(20);
  text("Mission: Find the missing bouquet!", 100, 100);

  // Check for click
  if (
    mouseIsPressed &&
    mouseX > bouquetX &&
    mouseX < bouquetX + 40 &&
    mouseY > bouquetY &&
    mouseY < bouquetY + 40
  ) {
    gameState = "missionComplete";
  }
}let bouquetX = 300;
let bouquetY = 300;

function drawCityScene() {
  fill(180);
  rect(0, height - 200, width, 200); // ground
  fill(100);
  rect(100, height - 300, 80, 100); // building
  rect(200, height - 400, 60, 200); // taller building
  rect(350, height - 250, 50, 50); // furniture store
}

function drawBouquet() {
  fill(255, 0, 100);
  ellipse(bouquetX, bouquetY, 40, 40);
}if (gameState === "missionComplete") {
  background(50, 200, 100);
  fill(255);
  textSize(32);
  text("You found the missing bouquet!", width / 2 - 200, height / 2);
}function handleYes() {
  gameState = "unknownLeaves";
  yesButton.hide();
  setTimeout(() => {
    gameState = "gearUp";
  }, 6000); // 6 seconds delay before gear up
}if (gameState === "unknownLeaves") {
  background(30);
  fill(255);
  textSize(18);
  text("Unknown has disappeared...", 100, 100);

  // Simulated text message
  text("TEXT: I got a house for you behind Lua Workshop.", 100, 150);
  text("There's a garden, a bed, and a packing station.", 100, 180);
  text("Check your tablet to see your house.", 100, 210);
  text("Visit Lua Workshop and step on the circle to buy stuff.", 100, 240);
}let tabletOpen = false;
let houseX = 400;
let houseY = 300;
let luaWorkshopX = 350;
let luaWorkshopY = 320;
if (gameState === "gearUp" && tabletOpen) {
  drawTabletMap();
} else if (gameState === "gearUp") {
  drawBenchScene();
  drawTabletIcon();
  drawPhoneIcon();

  // Selling flowers, etc...
}function drawTabletMap() {
  background(20);
  fill(255);
  textSize(16);
  text("MAP VIEW (Tablet)", 100, 40);

  // Lua Workshop
  fill(100, 100, 255);
  rect(luaWorkshopX, luaWorkshopY, 80, 40);
  fill(255);
  text("Lua Workshop", luaWorkshopX, luaWorkshopY - 10);

  // Player House
  fill(0, 255, 100);
  rect(houseX, houseY, 50, 50);
  text("Your House", houseX, houseY - 10);

  // Exit tablet
  fill(255, 0, 0);
  rect(width - 80, 20, 60, 30);
  fill(255);
  text("Exit", width - 65, 40);
}function mousePressed() {
  if (
    mouseX > width - 60 &&
    mouseX < width - 20 &&
    mouseY > 20 &&
    mouseY < 50
  ) {
    tabletOpen = !tabletOpen;
  }

  // Exit from map
  if (
    tabletOpen &&
    mouseX > width - 80 &&
    mouseX < width - 20 &&
    mouseY > 20 &&
    mouseY < 50
  ) {
    tabletOpen = false;
  }
}let playersServed = 0;
let currentFlower = '';
let currentAmount = 0;
let currentPrice = 0;

const flowers = {
  sunflower: { 5: 515, 4: 400, 3: 360, 2: 190, 1: 120 },
  lily:      { 5: 510, 4: 395, 3: 355, 2: 185, 1: 110 },
  vanilla:   { 5: 520, 4: 405, 3: 365, 2: 195, 1: 115 },
};

function getRandomFlower() {
  const flowerNames = Object.keys(flowers);
  return flowerNames[Math.floor(Math.random() * flowerNames.length)];
}

function newCustomer() {
  if (playersServed >= 500) {
    document.getElementById("gameText").innerText = 
      "Unknown: After all of these years, I will show you who I am...\nIt's your father, Papa Chang.";
    document.getElementById("deliveryTime").style.display = "none";
    return;
  }

  currentFlower = getRandomFlower();
  currentAmount = Math.floor(Math.random() * 5) + 1;
  currentPrice = flowers[currentFlower][currentAmount];

  document.getElementById("gameText").innerText = 
    `Customer: Give me ${currentAmount} ${currentFlower}(s) for $${currentPrice}`;
}

function respondYes() {
  document.getElementById("deliveryTime").style.display = "block";
}

function respondNo() {
  document.getElementById("gameText").innerText = "Customer: Okay, I'll text you tomorrow.";
  document.getElementById("deliveryTime").style.display = "none";
  setTimeout(newCustomer, 2000);
}

function chooseTime(time) {
  playersServed++;
  document.getElementById("gameText").innerText = 
    `You chose to deliver at: ${time}\nPeople served: ${playersServed}/500`;
  document.getElementById("deliveryTime").style.display = "none";
  setTimeout(newCustomer, 3000);
}

// Start the first customer
newCustomer();local playersServed = 0
local gameEnded = false

local flowers = {
    sunflower = { [5] = 515, [4] = 400, [3] = 360, [2] = 190, [1] = 120 },
    lily =      { [5] = 510, [4] = 395, [3] = 355, [2] = 185, [1] = 110 },
    vanilla =   { [5] = 520, [4] = 405, [3] = 365, [2] = 195, [1] = 115 },
}

function sendCustomerText()
    local flowerNames = { "sunflower", "lily", "vanilla" }
    local flower = flowerNames[math.random(1, #flowerNames)]
    local amount = math.random(1, 5)
    local price = flowers[flower][amount]

    print("Customer: Give me " .. amount .. " " .. flower .. "(s) for $" .. price)
    print("Type: yes or no")
    
    local answer = io.read()

    if answer == "yes" then
        print("Choose delivery time: Morning, Afternoon, Sunset, Night")
        local time = io.read()
        print("You chose to deliver at: " .. time)
        playersServed += 1
        checkProgress()
    else
        print("Customer: Okay, I'll text you tomorrow.")
    end
end

function checkProgress()
    if playersServed == 500 and not gameEnded then
        gameEnded = true
        unlockFinale()
    end
end

function unlockFinale()
    print("Unknown: After all of these years, I will show you who I am.")
    wait(3)
    print("Unknown: I am your father. My name is Papa Chang.")
    wait(3)
    print("*An old man walks out from the shadows*")
    wait(2)
    print("Papa Chang: You've done well, my child. The game ends here... or does it?")
    -- Add more game code or allow continued play
end

-- Game loop simulation (you can connect this to real game ticks or UI)
while not gameEnded do
    sendCustomerText()
end